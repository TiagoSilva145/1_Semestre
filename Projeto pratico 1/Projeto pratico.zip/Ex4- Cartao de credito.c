#include <math.h>

void soma_digitos (int cont, int *s1, int *s2, int numero)
{
    if(cont%2 == 0)
    {
        *s1=*s1 + numero;
        *s2=*s2 + (numero*2/10) + (numero*2%10);
    }
    else
    {
        *s1=*s1+ (numero*2/10) + (numero*2%10);
        *s2=*s2+ numero;
    }
}

void verifica_operadora(int operadora, int cont)
{
    if (cont == 16)
    {
        if(operadora/100 == 51 || operadora/100 == 55)
            printf("Mastercard. ");
        else if (operadora/1000 == 4)
            printf("Visa. ");
        else if (operadora == 6001)
            printf("Amex. ");
        else if (operadora/1000 == 3)
            printf("JCB. ");
        else
            printf("Desconhecida. ");
    }
    else if (cont == 15)
    {
        if(operadora/100 == 34 || operadora/100 == 37)
            printf("Amex. ");
        else if(operadora == 2014 || operadora == 2149)
            printf("enRoute. ");
        else if(operadora == 2131 || operadora == 1800)
            printf("JCB. ");
        else
            printf("Desconhecida. ");
    }
    else if (cont == 14)
    {
        if (operadora/100 == 30 || operadora/100 == 36 || operadora/100 == 38)
            printf("Dinners. ");
        else
            printf("Desconhecida. ");
    }
    else if (cont == 13)
    {
        if (operadora/1000 == 4)
            printf("Visa. ");
        else
            printf("Desconhecida. ");
    }
}

int main ()
{
    int numero,cont=0,
        s1=0,s2=0,sf;
    char caracter;
    double operadora=0;

    printf("Digite o numero do cartao, separando os digitos por espaco: ");

    while (caracter!=10)
    {
        scanf("%c", &caracter);

        if (caracter == 10)
            break;

        numero = (int)caracter - 48;

        if(numero < 0 || numero > 9)
        {
            printf("Caracteres invalidos.\n");
            return 0;
        }

        if(cont < 4)
            operadora = operadora + numero*(pow(10,3-cont));

        soma_digitos(cont,&s1,&s2,numero);
        cont++;
    }

    if(cont > 16)
    {
        printf("Numero muito longo.");
        return 0;
    }
    if(cont < 13)
    {
        printf("Numero muito curto.");
        return 0;
    }

    printf("Operadora: ");
    verifica_operadora (operadora,cont);

    if (cont%2)
        sf=s1;
    else
        sf=s2;

    if (sf%10 == 0)
        printf("Numero valido.");
    else
        printf("Numero invalido.");
}
