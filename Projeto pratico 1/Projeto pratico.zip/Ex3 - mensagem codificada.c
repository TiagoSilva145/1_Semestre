#include <stdio.h>

int bits1(int n) // retorna o numero de bits "1" em um numero binario fornecido
{
    int bits1=0,i;

    for(i=7;i>=0;i--)
    {
        if(n >= pow(2,i))
        {
            n = n - pow(2,i);
            bits1++;
        }
    }
    return bits1;
}

void codificar_mensagem ()
{
    unsigned char caracter;

    scanf("\n%c", &caracter);

    if(bits1(caracter)%2==1)
        caracter=caracter+128;

    printf("%d ", caracter);

    while (caracter != 46)
    {
        scanf("%c", &caracter);

        if(bits1(caracter)%2==1)
            caracter=caracter+128;

        printf("%d ", caracter);
    }
}

void decodificar_mensagem ()
{
    int letra;

    do
    {
        scanf("%d", &letra);
        if(letra > 126)
        {
            letra = letra - 128;

            if(bits1(letra) %2 == 0)
                printf("*");
            else
                printf("%c", letra);
        }
        else
            printf("%c", letra);

    } while(letra != 46);
}

int main ()
{
    int i;

    printf("Para enviar uma mensagem e codifica-la, digite 1\nPara decodificar uma mensagem, digite 2.\n");
    scanf ("%d", &i);

    if(i==1)
        codificar_mensagem();
    else
        decodificar_mensagem();
    return 0;
}
